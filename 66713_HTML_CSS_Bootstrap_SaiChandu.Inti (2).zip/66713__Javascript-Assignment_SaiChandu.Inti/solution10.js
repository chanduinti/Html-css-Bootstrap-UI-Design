//10.find duplicates in given array in dislay them like following
//    43 is repeated 3 times
//    23 is repeated 2 times

console.log("10.find duplicates in given array in dislay them like following")
console.log("10.1: 43 is repeated 3 times")
console.log("10.2: 23 is repeated 2 times")

let number = [65, 43, 98, 43, 23, 76, 32, 54, 23, 43];
let c = {}

function count_duplicate(a){
   
    for(let i =0; i < a.length; i++){ 
        if (c[a[i]]){
        c[a[i]] += 1
        } else {
        c[a[i]] = 1
        }
       }  
       for (let prop in c){
           if (c[prop] >= 2){
               console.log(prop + " repeated: " + c[prop] + " times.")
           }
       }
     
   }
   
   count_duplicate(number)