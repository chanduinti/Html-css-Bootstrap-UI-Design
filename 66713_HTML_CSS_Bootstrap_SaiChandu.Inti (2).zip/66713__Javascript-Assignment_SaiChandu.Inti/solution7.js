//7.update all the elements of given array by multiplying 10


console.log("7. Update all the elements of given array by multiplying 10")
let array=[65,43,98,43,23,76,32,54,23,43];

var ab = array.map(function(element) {
	return element*10;
});
console.log(ab);