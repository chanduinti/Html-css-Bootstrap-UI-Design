//2.find and display duplicate numbers

console.log("2. Find and display all duplicates")
let arr = [65, 43, 98, 43, 23, 76, 32, 54, 23, 43];
let counts = {}

function count_duplicate(a){
   
    for(let i =0; i < a.length; i++){ 
        if (counts[a[i]]){
        counts[a[i]] += 1
        console.log(a[i])

        } else {
        counts[a[i]] = 1
        }
        
       }  for (let prop in counts){
        if (counts[prop] >= 2){
            console.log(prop)
        }
    }
   }
   
   count_duplicate(arr)