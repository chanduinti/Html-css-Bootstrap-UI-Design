//5.remove all duplecates

console.log("5. Remove all the duplicates")
let xu=[65,43,98,43,23,76,32,54,23,43];


function RemoveDups(a){
    
    let uniquearray = [];
    
    for(let i of a) {
        if(uniquearray.indexOf(i) === -1) {
            uniquearray.push(i);
            
        }
    }
    console.log(uniquearray);


}

RemoveDups(xu);

