//9.Reverse givem array as immutable

console.log("9.Reverse given array as immutable")
const numblist=[65,43,98,43,23,76,32,54,23,43];
console.log( numblist.reverse());