//4.add new number into above given array (make sure new number should be unique)

console.log("4. Add new number into above given array (make sure new number should be unique)")
let n=[65,43,98,43,23,76,32,54,23,43];
console.log("Adding 10 in the array")
n.push(10);
console.log(n)