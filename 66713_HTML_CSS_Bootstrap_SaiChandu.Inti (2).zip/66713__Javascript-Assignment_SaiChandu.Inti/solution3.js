//3.replace 76 value with 175 (update)

console.log("3. Replace 76 value with 175 (update)")
let num=[65,43,98,43,23,76,32,54,23,43];
console.log("Og list:"+ num);
var i = num.indexOf(76);
num[i] = 175;
console.log("Updated list:"+ num);
