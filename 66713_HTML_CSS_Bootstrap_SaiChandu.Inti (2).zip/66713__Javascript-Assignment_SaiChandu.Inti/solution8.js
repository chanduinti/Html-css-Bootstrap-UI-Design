//8.Reverse given array as mutable

console.log("8.Reverse given array as mutable")
let numlist=[65,43,98,43,23,76,32,54,23,43];
console.log( numlist.reverse());