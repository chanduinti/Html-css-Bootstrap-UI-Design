//6.remove all duplecates and copy non duplicate array into new array

console.log("6.Remove all duplicates and copy non duplicate array into new array")

let x=[65,43,98,43,23,76,32,54,23,43];


function RemoveDups(a){
    
    let uniquearray = [];
    
    for(let i of a) {
        if(uniquearray.indexOf(i) === -1) {
            uniquearray.push(i);
            console.log(uniquearray);

        }
    }
    console.log(uniquearray);


}

RemoveDups(x);
