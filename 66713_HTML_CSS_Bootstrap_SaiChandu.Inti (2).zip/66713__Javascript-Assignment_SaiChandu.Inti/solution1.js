
console.log("1. Sort given array a-> A-Z (low to high) b-> Z-A (high to low)")
var numbers=[65,43,98,43,23,76,32,54,23,43];
console.log("Array a: " + numbers.sort());
console.log("Array b: " + numbers.reverse());